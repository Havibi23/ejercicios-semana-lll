/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { GoogleGenAI } from "@google/genai";
import { 
  Send, Bot, User, Sparkles, Loader2, 
  Paperclip, Image as ImageIcon, FileText, 
  Mic, X, File, Download, Trash2, Plus,
  Sun, Moon, Palette, Cpu, Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Markdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Theme = "dark" | "light" | "cyberpunk";

interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  base64?: string;
}

interface TokenUsage {
  promptTokens: number;
  candidatesTokens: number;
  totalTokens: number;
}

interface Message {
  role: "user" | "model";
  content: string;
  attachments?: Attachment[];
  usage?: TokenUsage;
}

export default function App() {
  const [theme, setTheme] = useState<Theme>("dark");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      content: "¡Hola! Soy Nexus AI. Estoy configurado para ayudarte con tu proyecto. Puedo procesar archivos, renderizar código y mostrarte el consumo de tokens en tiempo real.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Apply theme class to body
  useEffect(() => {
    document.body.className = theme === "light" ? "" : `${theme}-theme`;
  }, [theme]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(",")[1];
        resolve(base64String);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files) return;

    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append("file", file);

      try {
        const response = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) throw new Error("Upload failed");

        const data = await response.json();
        const base64 = await fileToBase64(file);

        const newAttachment: Attachment = {
          id: Math.random().toString(36).substring(7),
          name: data.originalName,
          type: data.mimeType,
          size: data.size,
          url: data.path,
          base64: base64
        };

        setAttachments(prev => [...prev, newAttachment]);
      } catch (error) {
        console.error("Upload error:", error);
      }
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleSend = async () => {
    if ((!input.trim() && attachments.length === 0) || isLoading) return;

    const userMessage = input.trim();
    const currentAttachments = [...attachments];
    
    setInput("");
    setAttachments([]);
    setMessages((prev) => [...prev, { 
      role: "user", 
      content: userMessage || (currentAttachments.length > 0 ? "Analiza estos archivos." : ""),
      attachments: currentAttachments 
    }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const parts: any[] = [];
      
      if (userMessage) {
        parts.push({ text: userMessage });
      }

      for (const att of currentAttachments) {
        if (att.base64) {
          parts.push({
            inlineData: {
              data: att.base64,
              mimeType: att.type
            }
          });
        }
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts },
        config: {
          systemInstruction: "Eres un asistente técnico experto. Si el usuario te pide código, proporciónalo en bloques Markdown con el lenguaje especificado. Responde siempre en español.",
        }
      });

      const text = response.text;
      const usage = response.usageMetadata;

      if (text) {
        setMessages((prev) => [...prev, { 
          role: "model", 
          content: text,
          usage: usage ? {
            promptTokens: usage.promptTokenCount || 0,
            candidatesTokens: usage.candidatesTokenCount || 0,
            totalTokens: usage.totalTokenCount || 0
          } : undefined
        }]);
      }
    } catch (error) {
      console.error("Error calling Gemini:", error);
      setMessages((prev) => [
        ...prev,
        { role: "model", content: "Error en la conexión con la API. Verifica tu configuración." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileUpload(e.dataTransfer.files);
  }, []);

  return (
    <div 
      className={cn("flex flex-col h-screen transition-all duration-300 overflow-hidden")}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      style={{ backgroundColor: "var(--bg-color)", color: "var(--text-color)" }}
    >
      {/* Drag Overlay */}
      <AnimatePresence>
        {isDragging && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-indigo-600/20 backdrop-blur-sm border-4 border-dashed border-indigo-500 flex items-center justify-center"
          >
            <div className="text-center">
              <Plus size={64} className="mx-auto text-indigo-400 mb-4 animate-bounce" />
              <h2 className="text-2xl font-bold">Suelta tus archivos aquí</h2>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header 
        className={cn("flex items-center justify-between px-6 py-4 backdrop-blur-md border-b z-10")}
        style={{ backgroundColor: "var(--header-bg)", borderColor: "var(--border-color)" }}
      >
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center shadow-lg",
            theme === "cyberpunk" ? "bg-black border border-[#00ff41]" : "bg-gradient-to-br from-indigo-600 to-violet-700"
          )}>
            <Bot size={24} className={theme === "cyberpunk" ? "text-[#00ff41]" : "text-white"} />
          </div>
          <div>
            <h1 className={cn(
              "text-lg font-bold tracking-tight",
              theme === "cyberpunk" ? "text-[#00ff41]" : "text-current"
            )}>Nexus AI v2.0</h1>
            <div className="flex items-center gap-1.5">
              <span className={cn("w-1.5 h-1.5 rounded-full animate-pulse", theme === "cyberpunk" ? "bg-[#00ff41]" : "bg-emerald-500")} />
              <p className="text-[10px] opacity-50 font-bold uppercase tracking-widest">Token Tracking Enabled</p>
            </div>
          </div>
        </div>

        {/* Theme Selector */}
        <div className="flex items-center gap-2 p-1 bg-white/5 rounded-2xl border border-white/10">
          <button 
            onClick={() => setTheme("light")}
            className={cn("p-2 rounded-xl transition-all", theme === "light" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-white")}
          >
            <Sun size={18} />
          </button>
          <button 
            onClick={() => setTheme("dark")}
            className={cn("p-2 rounded-xl transition-all", theme === "dark" ? "bg-white/10 text-white" : "text-slate-500 hover:text-white")}
          >
            <Moon size={18} />
          </button>
          <button 
            onClick={() => setTheme("cyberpunk")}
            className={cn("p-2 rounded-xl transition-all", theme === "cyberpunk" ? "bg-[#00ff41]/20 text-[#00ff41]" : "text-slate-500 hover:text-white")}
          >
            <Palette size={18} />
          </button>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 scrollbar-hide">
        <div className="max-w-4xl mx-auto space-y-8">
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-4 group",
                msg.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div 
                className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-xl border",
                )}
                style={{ 
                  backgroundColor: msg.role === "user" ? "var(--primary-color)" : "var(--card-bg)",
                  borderColor: "var(--border-color)",
                  color: msg.role === "user" ? "var(--user-msg-text)" : "var(--primary-color)"
                }}
              >
                {msg.role === "user" ? <User size={20} /> : <Bot size={20} />}
              </div>
              
              <div className={cn(
                "flex flex-col gap-2 max-w-[85%]",
                msg.role === "user" ? "items-end" : "items-start"
              )}>
                {/* Attachments Metadata Display */}
                {msg.attachments && msg.attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-1">
                    {msg.attachments.map(att => (
                      <div 
                        key={att.id} 
                        className={cn("rounded-lg p-2.5 flex items-center gap-3 text-xs border")}
                        style={{ backgroundColor: "var(--card-bg)", borderColor: "var(--border-color)" }}
                      >
                        <div className="p-1.5 bg-indigo-500/10 rounded-md text-indigo-400">
                          {att.type.startsWith("image/") ? <ImageIcon size={14} /> : <FileText size={14} />}
                        </div>
                        <div className="flex flex-col">
                          <span className="font-bold">{att.name}</span>
                          <span className="opacity-50 text-[10px]">{(att.size / 1024).toFixed(1)} KB • {att.type.split("/")[1].toUpperCase()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div 
                  className={cn("px-5 py-3.5 rounded-2xl shadow-2xl backdrop-blur-sm border")}
                  style={{ 
                    backgroundColor: msg.role === "user" ? "var(--user-msg-bg)" : "var(--bot-msg-bg)",
                    borderColor: "var(--border-color)",
                    color: msg.role === "user" ? "var(--user-msg-text)" : "var(--bot-msg-text)",
                    borderTopRightRadius: msg.role === "user" ? "0" : "1rem",
                    borderTopLeftRadius: msg.role === "user" ? "1rem" : "0"
                  }}
                >
                  <div className={cn(
                    "prose prose-sm max-w-none prose-p:leading-relaxed markdown-body",
                    theme === "light" ? "prose-slate" : "prose-invert",
                    theme === "cyberpunk" && "prose-p:text-[#00ff41] prose-headings:text-[#00ff41] prose-strong:text-[#00ff41]"
                  )}>
                    <Markdown
                      components={{
                        code({ node, inline, className, children, ...props }: any) {
                          const match = /language-(\w+)/.exec(className || "");
                          return !inline && match ? (
                            <SyntaxHighlighter
                              style={vscDarkPlus}
                              language={match[1]}
                              PreTag="div"
                              {...props}
                            >
                              {String(children).replace(/\n$/, "")}
                            </SyntaxHighlighter>
                          ) : (
                            <code className={className} {...props}>
                              {children}
                            </code>
                          );
                        },
                      }}
                    >
                      {msg.content}
                    </Markdown>
                  </div>
                </div>

                {/* Token Usage Display */}
                {msg.usage && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={cn("flex items-center gap-3 mt-1 px-3 py-1 rounded-full text-[10px] font-bold tracking-wider border")}
                    style={{ borderColor: "var(--border-color)", opacity: 0.7 }}
                  >
                    <div className="flex items-center gap-1">
                      <Cpu size={10} />
                      <span>INPUT: {msg.usage.promptTokens}</span>
                    </div>
                    <div className="w-1 h-1 bg-current opacity-20 rounded-full" />
                    <div className="flex items-center gap-1">
                      <Sparkles size={10} />
                      <span>OUTPUT: {msg.usage.candidatesTokens}</span>
                    </div>
                    <div className="w-1 h-1 bg-current opacity-20 rounded-full" />
                    <div className="flex items-center gap-1">
                      <Info size={10} />
                      <span>TOTAL: {msg.usage.totalTokens}</span>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
          
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4">
              <div 
                className={cn("w-10 h-10 rounded-xl flex items-center justify-center shadow-xl border")}
                style={{ backgroundColor: "var(--card-bg)", borderColor: "var(--border-color)", color: "var(--primary-color)" }}
              >
                <Bot size={20} />
              </div>
              <div 
                className={cn("px-5 py-3.5 rounded-2xl rounded-tl-none shadow-2xl flex items-center gap-3 border")}
                style={{ backgroundColor: "var(--card-bg)", borderColor: "var(--border-color)" }}
              >
                <Loader2 size={16} className={cn("animate-spin text-indigo-500")} />
                <span className={cn("text-xs font-medium uppercase tracking-widest opacity-50")}>
                  Calculando Tokens...
                </span>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer 
        className={cn("p-4 md:p-6 backdrop-blur-xl border-t")}
        style={{ backgroundColor: "var(--header-bg)", borderColor: "var(--border-color)" }}
      >
        <div className="max-w-4xl mx-auto space-y-4">
          
          {/* Attachment Previews */}
          <AnimatePresence>
            {attachments.length > 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="flex flex-wrap gap-2 pb-2"
              >
                {attachments.map(att => (
                  <div 
                    key={att.id} 
                    className={cn("group relative border rounded-xl p-2 pr-8 flex items-center gap-3")}
                    style={{ backgroundColor: "var(--card-bg)", borderColor: "var(--border-color)" }}
                  >
                    <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center text-indigo-400">
                      {att.type.startsWith("image/") ? <ImageIcon size={16} /> : <FileText size={16} />}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-medium max-w-[150px] truncate">{att.name}</span>
                      <span className="text-[10px] opacity-50">{(att.size / 1024).toFixed(1)} KB</span>
                    </div>
                    <button 
                      onClick={() => removeAttachment(att.id)}
                      className="absolute right-1.5 top-1.5 p-1 hover:text-red-400 transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative flex items-end gap-2">
            <div className="flex-1 relative">
              <textarea
                rows={1}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Escribe un mensaje o suelta archivos..."
                className={cn(
                  "w-full pl-4 pr-12 py-4 border rounded-2xl focus:outline-none transition-all resize-none max-h-40",
                )}
                style={{ 
                  backgroundColor: "var(--card-bg)", 
                  borderColor: "var(--border-color)",
                  color: "var(--text-color)"
                }}
              />
              <div className="absolute right-2 bottom-2 flex items-center gap-1">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 text-slate-400 hover:text-indigo-400 transition-colors rounded-xl"
                >
                  <Paperclip size={20} />
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  multiple
                  onChange={(e) => handleFileUpload(e.target.files)}
                />
              </div>
            </div>
            
            <button
              onClick={handleSend}
              disabled={(!input.trim() && attachments.length === 0) || isLoading}
              className={cn("p-4 rounded-2xl transition-all shadow-lg active:scale-95 text-white")}
              style={{ backgroundColor: "var(--primary-color)" }}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}




